import MetaBar from "@/components/layout/MetaBar";
import Header from "@/components/layout/Header";
import ProductCard from "@/components/shop/ProductCard";
import { getFeaturedProducts, getFeaturedMaker, getCategoryCounts } from "@/lib/data";
import type { Category } from "@/types";

const CATEGORIES: { key: Category; label: string; icon: React.ReactNode }[] = [
  {
    key: "textiles",
    label: "Textiles",
    icon: <path d="M12 2c-3 4-3 8 0 12 3-4 3-8 0-12zM4 14c4-2 8-2 12 0M4 18c4-2 8-2 12 0M6 22c2-1 4-1 6 0"/>,
  },
  {
    key: "leather",
    label: "Leather",
    icon: <><path d="M4 8c0-2 2-4 4-4h8c2 0 4 2 4 4v10c0 2-2 4-4 4H8c-2 0-4-2-4-4V8z"/><path d="M9 4v4M15 4v4"/></>,
  },
  {
    key: "ceramics",
    label: "Ceramics",
    icon: <path d="M8 4h8v3c0 1-1 2-2 2h-1v9c0 2 1 3 2 4H7c1-1 2-2 2-4V9H8c-1 0-2-1-2-2V4z"/>,
  },
  {
    key: "wood",
    label: "Wood",
    icon: <path d="M12 2v20M8 6l4-4 4 4M6 12l6-6 6 6M4 18l8-8 8 8"/>,
  },
  {
    key: "provisions",
    label: "Provisions",
    icon: <><rect x="6" y="8" width="12" height="14" rx="1"/><path d="M9 8V4c0-1 1-2 2-2h2c1 0 2 1 2 2v4"/><path d="M6 12h12"/></>,
  },
  {
    key: "curios",
    label: "Curios",
    icon: <><circle cx="12" cy="12" r="9"/><path d="M12 3v18M3 12h18M12 6l3 6-3 6-3-6 3-6z"/></>,
  },
];

export default async function Home() {
  const products = await getFeaturedProducts(6);
  const featuredMaker = await getFeaturedMaker();
  const counts = await getCategoryCounts();

  return (
    <>
      <MetaBar />
      <Header />

      {/* HERO */}
      <section
        style={{
          position: "relative",
          minHeight: "88vh",
          overflow: "hidden",
          borderBottom: "1px solid var(--ink)",
          background: "var(--ink)",
        }}
      >
        {/* SVG Landscape */}
        <div style={{ position: "absolute", inset: 0, zIndex: 0 }}>
          <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" style={{ width: "100%", height: "100%" }}>
            <defs>
              <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1a2422"/>
                <stop offset="40%" stopColor="#243632"/>
                <stop offset="70%" stopColor="#3a4a44"/>
                <stop offset="100%" stopColor="#5a6660"/>
              </linearGradient>
              <linearGradient id="mtn1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1f2d2a"/>
                <stop offset="100%" stopColor="#0e1614"/>
              </linearGradient>
              <linearGradient id="mtn2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2a3a36"/>
                <stop offset="100%" stopColor="#152220"/>
              </linearGradient>
              <linearGradient id="mtn3" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3d4d46"/>
                <stop offset="100%" stopColor="#1a2522"/>
              </linearGradient>
              <linearGradient id="water" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1a2624"/>
                <stop offset="100%" stopColor="#0a1210"/>
              </linearGradient>
              <linearGradient id="darken" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#1a2422" stopOpacity="0.95"/>
                <stop offset="40%" stopColor="#1a2422" stopOpacity="0.7"/>
                <stop offset="100%" stopColor="#1a2422" stopOpacity="0.45"/>
              </linearGradient>
            </defs>
            <rect width="1600" height="900" fill="url(#sky)"/>
            <path d="M0,520 L100,450 L180,490 L260,420 L340,460 L450,400 L560,470 L680,410 L800,460 L920,400 L1040,470 L1160,420 L1280,480 L1400,440 L1520,490 L1600,460 L1600,900 L0,900 Z" fill="url(#mtn3)" opacity="0.55"/>
            <path d="M0,580 L80,540 L160,560 L240,470 L340,510 L440,460 L540,520 L660,450 L780,500 L900,440 L1020,510 L1160,460 L1280,520 L1400,480 L1520,540 L1600,510 L1600,900 L0,900 Z" fill="url(#mtn2)" opacity="0.85"/>
            <path d="M0,620 L60,580 L130,610 L200,540 L260,580 L330,510 L420,560 L500,500 L580,540 L660,490 L740,540 L820,510 L900,560 L980,520 L1060,580 L1140,540 L1240,590 L1340,560 L1440,610 L1540,580 L1600,610 L1600,900 L0,900 Z" fill="url(#mtn1)"/>
            <rect y="700" width="1600" height="200" fill="url(#water)"/>
            <rect width="1600" height="900" fill="url(#darken)"/>
          </svg>
        </div>

        {/* Hero content */}
        <div style={{ position: "relative", zIndex: 2, padding: "100px 48px 120px", color: "var(--paper)", display: "grid", gridTemplateColumns: "1.3fr 1fr", gap: "80px", alignItems: "end", minHeight: "88vh" }}>
          <div>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.3em", textTransform: "uppercase", marginBottom: "32px", display: "flex", gap: "24px", color: "var(--gold)" }}>
              <span>Vol. I</span>
              <span>Spring 2026</span>
              <span>Punta Arenas</span>
            </div>
            <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(56px, 8.5vw, 132px)", lineHeight: 0.88, letterSpacing: "-0.04em", fontWeight: 300, marginBottom: "32px", color: "var(--paper-light)" }}>
              Made at the<br />
              <em style={{ fontStyle: "italic", fontWeight: 400, color: "var(--gold)" }}>edge</em> of the<br />
              <strong style={{ fontWeight: 900 }}>known world.</strong>
            </h1>
            <p style={{ fontFamily: "var(--font-body)", fontSize: "22px", fontStyle: "italic", color: "rgba(237,228,211,0.85)", maxWidth: "540px", marginBottom: "40px", lineHeight: 1.45 }}>
              A curated marketplace of textiles, leather, ceramics and provisions — handcrafted across the windswept south of Chile by the people who still remember how.
            </p>
            <a href="#shop" style={{ display: "inline-flex", alignItems: "center", gap: "12px", padding: "16px 28px", background: "var(--rust)", color: "var(--paper)", fontFamily: "var(--font-mono)", fontSize: "12px", letterSpacing: "0.2em", textTransform: "uppercase", border: "1px solid var(--rust)", transition: "all 0.3s" }}>
              Browse the Collection →
            </a>
          </div>

          {/* Stats sidebar */}
          <div style={{ borderLeft: "1px solid rgba(237,228,211,0.25)", paddingLeft: "40px" }}>
            {[
              { label: "Local Makers", value: "42", unit: "artisans" },
              { label: "Pieces in Stock", value: "316", unit: "handmade" },
              { label: "Latitude", value: "53°S", unit: "southernmost" },
            ].map(({ label, value, unit }) => (
              <div key={label} style={{ marginBottom: "36px" }}>
                <div style={{ fontFamily: "var(--font-mono)", fontSize: "10px", letterSpacing: "0.25em", textTransform: "uppercase", color: "var(--gold)", marginBottom: "8px" }}>{label}</div>
                <div style={{ fontFamily: "var(--font-display)", fontSize: "36px", fontWeight: 300, lineHeight: 1, letterSpacing: "-0.02em", color: "var(--paper-light)" }}>
                  {value}
                  <span style={{ fontSize: "14px", fontStyle: "italic", color: "rgba(237,228,211,0.6)", marginLeft: "4px" }}>{unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div style={{ background: "var(--ink)", color: "var(--paper)", padding: "14px 0", overflow: "hidden", borderBottom: "1px solid var(--ink)", position: "relative", zIndex: 2 }}>
        <div style={{ display: "flex", animation: "marquee 50s linear infinite", whiteSpace: "nowrap", fontFamily: "var(--font-mono)", fontSize: "12px", letterSpacing: "0.2em", textTransform: "uppercase" }}>
          {["Hand-spun Patagonian wool", "Smoked king crab preserves", "Lenga wood carving", "Estancia leather goods", "Calafate fruit jams", "Hotel delivery within hours"].map((item) => (
            <span key={item} style={{ paddingRight: "60px", display: "inline-flex", alignItems: "center", gap: "60px" }}>
              {item} <span style={{ color: "var(--rust)" }}>✦</span>
            </span>
          ))}
          {/* Duplicate for seamless loop */}
          {["Hand-spun Patagonian wool", "Smoked king crab preserves", "Lenga wood carving", "Estancia leather goods", "Calafate fruit jams", "Hotel delivery within hours"].map((item) => (
            <span key={`dup-${item}`} style={{ paddingRight: "60px", display: "inline-flex", alignItems: "center", gap: "60px" }}>
              {item} <span style={{ color: "var(--rust)" }}>✦</span>
            </span>
          ))}
        </div>
      </div>

      {/* STATUS BAR */}
      <div style={{ padding: "24px 48px", background: "var(--paper-deep)", borderBottom: "1px solid var(--ink)", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "32px", flexWrap: "wrap", position: "relative", zIndex: 2 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "16px", fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.15em", textTransform: "uppercase" }}>
          <div style={{ width: "8px", height: "8px", background: "var(--moss)", borderRadius: "50%", boxShadow: "0 0 0 4px rgba(74,93,58,0.2)", animation: "pulse 2s ease-in-out infinite" }} />
          Open Now in Punta Arenas
        </div>
        <div style={{ display: "flex", gap: "32px", fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.1em", color: "var(--ink-soft)", flexWrap: "wrap" }}>
          <span><b style={{ color: "var(--ink)" }}>Local Time:</b> 14:32</span>
          <span><b style={{ color: "var(--ink)" }}>Weather:</b> 6°C · Wind 45 km/h SW</span>
          <span><b style={{ color: "var(--ink)" }}>Cruise Day:</b> 3 ships in port</span>
          <span><b style={{ color: "var(--ink)" }}>Hotel Delivery:</b> Same day before 18:00</span>
        </div>
      </div>

      {/* CATEGORIES */}
      <section style={{ padding: "100px 48px", borderBottom: "1px solid var(--ink)", position: "relative", zIndex: 2 }} id="shop">
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", alignItems: "end", gap: "32px", marginBottom: "64px", borderBottom: "1px solid var(--ink)", paddingBottom: "24px" }}>
          <div className="section-number">— I.</div>
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(40px,5vw,64px)", fontWeight: 400, letterSpacing: "-0.03em", lineHeight: 1 }}>
            By <em style={{ fontStyle: "italic", color: "var(--rust)" }}>Trade</em>
          </h2>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "10px", letterSpacing: "0.25em", textTransform: "uppercase", color: "var(--ink-soft)", textAlign: "right" }}>
            Six disciplines · {products.length * 5} works
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(6,1fr)", gap: "1px", background: "var(--ink)", border: "1px solid var(--ink)" }}>
          {CATEGORIES.map(({ key, label, icon }) => (
            <div
              key={key}
              className="fade-in"
              style={{ background: "var(--paper)", padding: "36px 24px", cursor: "pointer", transition: "all 0.3s", textAlign: "center" }}
              onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.background = "var(--ink)"; (e.currentTarget as HTMLElement).style.color = "var(--paper)"; }}
              onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.background = "var(--paper)"; (e.currentTarget as HTMLElement).style.color = "var(--ink)"; }}
            >
              <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ margin: "0 auto 14px", color: "var(--rust)" }}>
                {icon}
              </svg>
              <div style={{ fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: "6px" }}>{label}</div>
              <div style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: "13px", color: "var(--ink-soft)" }}>{counts[key] || 0} pieces</div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED PRODUCTS */}
      <section style={{ padding: "100px 48px", borderBottom: "1px solid var(--ink)", position: "relative", zIndex: 2 }}>
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", alignItems: "end", gap: "32px", marginBottom: "64px", borderBottom: "1px solid var(--ink)", paddingBottom: "24px" }}>
          <div className="section-number">— II.</div>
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(40px,5vw,64px)", fontWeight: 400, letterSpacing: "-0.03em", lineHeight: 1 }}>
            This <em style={{ fontStyle: "italic", color: "var(--rust)" }}>Week&apos;s</em> Catch
          </h2>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "10px", letterSpacing: "0.25em", textTransform: "uppercase", color: "var(--ink-soft)", textAlign: "right" }}>
            Curated · Updated Mondays
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "56px 32px" }}>
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* MAKER FEATURE */}
      {featuredMaker && (
        <section
          id="makers"
          style={{
            background: "var(--teal-deep)",
            color: "var(--paper)",
            borderBottom: "1px solid var(--ink)",
            position: "relative",
            zIndex: 2,
            display: "grid",
            gridTemplateColumns: "1fr 1.2fr",
            minHeight: "600px",
          }}
        >
          {/* Portrait placeholder */}
          <div style={{ background: "#0d2220", display: "flex", alignItems: "center", justifyContent: "center", minHeight: "600px", position: "relative" }}>
            <div style={{ textAlign: "center", opacity: 0.3 }}>
              <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="0.5">
                <circle cx="12" cy="8" r="4"/>
                <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
              </svg>
              <p style={{ fontFamily: "var(--font-mono)", fontSize: "9px", letterSpacing: "0.2em", textTransform: "uppercase", marginTop: "12px", color: "var(--gold)" }}>
                Portrait · {featuredMaker.name}
              </p>
            </div>
            <div style={{ position: "absolute", bottom: "32px", left: "32px", fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: "14px", color: "var(--gold)", letterSpacing: "0.15em", textTransform: "uppercase" }}>
              — Maker №14 / {featuredMaker.location}
            </div>
          </div>

          {/* Maker text */}
          <div style={{ padding: "100px 64px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
            <div style={{ fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.3em", textTransform: "uppercase", color: "var(--gold)", marginBottom: "24px", display: "flex", alignItems: "center", gap: "12px" }}>
              <span style={{ display: "inline-block", width: "32px", height: "1px", background: "var(--gold)" }} />
              Maker of the Month
            </div>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(40px,5vw,72px)", fontWeight: 300, lineHeight: 1, letterSpacing: "-0.02em", marginBottom: "32px" }}>
              {featuredMaker.name}<br />
              <em style={{ fontStyle: "italic", color: "var(--gold)" }}>spins the wind.</em>
            </h2>
            <p style={{ fontFamily: "var(--font-body)", fontSize: "19px", lineHeight: 1.7, marginBottom: "32px", color: "rgba(237,228,211,0.85)", maxWidth: "540px" }}>
              {featuredMaker.bio}
            </p>
            <blockquote style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: "24px", lineHeight: 1.4, borderLeft: "2px solid var(--gold)", paddingLeft: "24px", marginBottom: "40px" }}>
              &ldquo;{featuredMaker.quote}&rdquo;
            </blockquote>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,auto)", gap: "48px", fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.15em", textTransform: "uppercase", color: "rgba(237,228,211,0.6)", paddingTop: "32px", borderTop: "1px solid rgba(237,228,211,0.2)" }}>
              <div>Based in <b style={{ display: "block", color: "var(--paper)", fontFamily: "var(--font-display)", fontSize: "18px", fontWeight: 400, textTransform: "none", letterSpacing: 0, marginTop: "4px" }}>{featuredMaker.location}</b></div>
              <div>Working since <b style={{ display: "block", color: "var(--paper)", fontFamily: "var(--font-display)", fontSize: "18px", fontWeight: 400, textTransform: "none", letterSpacing: 0, marginTop: "4px" }}>{featuredMaker.workingSince}</b></div>
              <div>Pieces listed <b style={{ display: "block", color: "var(--paper)", fontFamily: "var(--font-display)", fontSize: "18px", fontWeight: 400, textTransform: "none", letterSpacing: 0, marginTop: "4px" }}>14</b></div>
            </div>
          </div>
        </section>
      )}

      {/* HOW IT WORKS */}
      <section style={{ padding: "100px 48px", borderBottom: "1px solid var(--ink)", position: "relative", zIndex: 2 }} id="story">
        <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", alignItems: "end", gap: "32px", marginBottom: "64px", borderBottom: "1px solid var(--ink)", paddingBottom: "24px" }}>
          <div className="section-number">— IV.</div>
          <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(40px,5vw,64px)", fontWeight: 400, letterSpacing: "-0.03em", lineHeight: 1 }}>
            How it <em style={{ fontStyle: "italic", color: "var(--rust)" }}>works</em>
          </h2>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: "10px", letterSpacing: "0.25em", textTransform: "uppercase", color: "var(--ink-soft)", textAlign: "right" }}>
            For travelers · simple terms
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "1px", background: "var(--ink)" }}>
          {[
            { num: "i.", title: "Browse anytime, anywhere", body: "Closed shops, late flights, public holidays — the marketplace doesn't sleep. Discover makers across Magallanes from your hotel, your plane, or your sofa back home." },
            { num: "ii.", title: "Pay in your currency", body: "Checkout in USD, EUR, or your card's native currency. We handle the conversion and pay the maker in Chilean pesos. No friction, no surprise fees." },
            { num: "iii.", title: "Choose how it reaches you", body: "Delivery to your hotel or accommodation in Punta Arenas and surrounding areas, or pickup directly at the maker's workshop. Every piece travels with the maker's story and a card hand-signed at origin." },
          ].map(({ num, title, body }) => (
            <div key={num} className="fade-in" style={{ background: "var(--paper)", padding: "56px 40px" }}>
              <div style={{ fontFamily: "var(--font-display)", fontStyle: "italic", fontSize: "96px", lineHeight: 0.8, color: "var(--rust)", marginBottom: "24px", fontWeight: 300 }}>{num}</div>
              <h3 style={{ fontFamily: "var(--font-display)", fontSize: "28px", fontWeight: 500, letterSpacing: "-0.01em", lineHeight: 1.15, marginBottom: "16px" }}>{title}</h3>
              <p style={{ fontFamily: "var(--font-body)", fontSize: "17px", lineHeight: 1.6, color: "var(--ink-soft)" }}>{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* NEWSLETTER */}
      <section style={{ background: "var(--ink)", color: "var(--paper)", padding: "100px 48px", textAlign: "center", borderBottom: "1px solid var(--ink)", position: "relative", zIndex: 2 }}>
        <h2 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(36px,5vw,56px)", fontWeight: 300, lineHeight: 1, letterSpacing: "-0.02em", marginBottom: "20px" }}>
          Letters from <em style={{ fontStyle: "italic", color: "var(--gold)" }}>the south.</em>
        </h2>
        <p style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: "19px", color: "rgba(237,228,211,0.7)", maxWidth: "540px", margin: "0 auto 40px" }}>
          One slow email a month. Stories from the workshops, new arrivals, weather from the strait. Nothing else.
        </p>
        <div style={{ display: "flex", maxWidth: "480px", margin: "0 auto", border: "1px solid rgba(237,228,211,0.3)" }}>
          <input
            type="email"
            placeholder="your@email.com"
            style={{ flex: 1, padding: "16px 20px", background: "transparent", border: "none", color: "var(--paper)", fontFamily: "var(--font-display)", fontSize: "16px", outline: "none" }}
          />
          <button style={{ padding: "16px 28px", background: "var(--gold)", border: "none", color: "var(--ink)", fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.2em", textTransform: "uppercase", transition: "background 0.3s" }}>
            Subscribe
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ background: "var(--ink)", color: "var(--paper)", padding: "80px 48px 32px", position: "relative", zIndex: 2 }}>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: "48px", marginBottom: "64px", paddingBottom: "48px", borderBottom: "1px solid rgba(237,228,211,0.2)" }}>
          <div>
            <div style={{ fontFamily: "var(--font-display)", fontWeight: 900, fontSize: "24px", marginBottom: "24px" }}>
              <span style={{ display: "block", fontStyle: "italic", fontWeight: 400, fontSize: "11px", letterSpacing: "0.3em", textTransform: "uppercase", color: "var(--gold)", marginBottom: "6px" }}>Est. 2026 — Magallanes</span>
              Patagonia <span style={{ color: "var(--gold)", fontStyle: "italic" }}>&amp;</span> Made
            </div>
            <p style={{ fontFamily: "var(--font-body)", fontStyle: "italic", fontSize: "17px", lineHeight: 1.6, color: "rgba(237,228,211,0.7)", maxWidth: "380px" }}>
              A marketplace for the makers of the windswept south. Every piece bears the latitude of the hands that made it.
            </p>
          </div>
          {[
            { title: "Shop", links: ["All collections", "Textiles", "Provisions", "Gift cards"] },
            { title: "Makers", links: ["Meet the artisans", "Apply to sell", "Maker stories", "Fair trade"] },
            { title: "Travelers", links: ["Hotel delivery", "Surrounding areas", "Workshop pickup", "Contact"] },
          ].map(({ title, links }) => (
            <div key={title}>
              <h4 style={{ fontFamily: "var(--font-mono)", fontSize: "11px", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: "24px", color: "var(--gold)", fontWeight: 500 }}>{title}</h4>
              <ul style={{ listStyle: "none" }}>
                {links.map((link) => (
                  <li key={link} style={{ marginBottom: "12px" }}>
                    <a href="#" style={{ color: "rgba(237,228,211,0.75)", fontFamily: "var(--font-display)", fontSize: "16px", transition: "color 0.2s" }}>{link}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", fontFamily: "var(--font-mono)", fontSize: "10px", letterSpacing: "0.2em", textTransform: "uppercase", color: "rgba(237,228,211,0.5)" }}>
          <span>© 2026 Patagonia &amp; Made · Punta Arenas, Chile</span>
          <span>53°09′S 70°55′W · The Strait of Magellan</span>
        </div>
      </footer>
    </>
  );
}
