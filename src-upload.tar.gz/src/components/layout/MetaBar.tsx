export default function MetaBar() {
  return (
    <div
      style={{
        background: "var(--ink)",
        color: "var(--paper)",
        padding: "8px 32px",
        fontFamily: "var(--font-mono)",
        fontSize: "11px",
        letterSpacing: "0.08em",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        position: "relative",
        zIndex: 10,
      }}
    >
      <span style={{ opacity: 0.7 }}>53°09′S — 70°55′W · PUNTA ARENAS, CHILE</span>
      <div style={{ display: "flex", gap: "20px", alignItems: "center" }}>
        <span style={{ opacity: 0.85 }}>USD ▾</span>
        <span style={{ opacity: 0.4 }}>/</span>
        <span style={{ opacity: 0.85 }}>Free hotel delivery</span>
      </div>
    </div>
  );
}
